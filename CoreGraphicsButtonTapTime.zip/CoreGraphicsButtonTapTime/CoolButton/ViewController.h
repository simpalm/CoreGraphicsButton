//
//  ViewController.h
//  CoolButton
//
//  Created by Brian Moakley on 2/21/13.
//  Copyright (c) 2013 Razeware. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CoolButton;

@interface ViewController : UIViewController

@property (nonatomic, weak) IBOutlet CoolButton * coolButton;
@property(weak, nonatomic) IBOutlet UILabel *lblTime;

@end
