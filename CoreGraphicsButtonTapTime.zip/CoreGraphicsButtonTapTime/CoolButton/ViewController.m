//
//  ViewController.m
//  CoolButton
//
//  Created by Brian Moakley on 2/21/13.
//  Copyright (c) 2013 Razeware. All rights reserved.
//

#import "ViewController.h"
#import "CoolButton.h"

@interface ViewController ()
{
    NSDate *previousDte;

}

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)BtnClicked:(UIButton *)sender {
    NSDate *now = [NSDate date];
    NSTimeInterval seconds = [now timeIntervalSinceDate:previousDte];
    double milliseconds = seconds*1000;
    NSLog(@"Time passed: %f milisec", milliseconds);
    self.lblTime.text = [NSString stringWithFormat:@"Time difference: %f milisec", milliseconds];
    previousDte = now;
}


@end
